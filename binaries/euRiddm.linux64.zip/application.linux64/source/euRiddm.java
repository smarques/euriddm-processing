import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Arrays; 
import beads.*; 
import controlP5.*; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.FileInputStream; 
import java.io.FileNotFoundException; 
import java.io.IOException; 
import java.io.BufferedInputStream; 
import java.net.MalformedURLException; 
import java.net.URL; 
import javax.sound.sampled.AudioFormat; 
import javax.sound.sampled.AudioSystem; 
import javax.sound.sampled.DataLine; 
import javax.sound.sampled.LineUnavailableException; 
import javax.sound.sampled.SourceDataLine; 
import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class euRiddm extends PApplet {









ColorScheme[] colorSchemes;
BeatKeeper beatKeeper;
RhythmPlayer[] players;
int trackNumber = 3;
AudioContext audioContext;
CirclesVisualizer circleVisualizer; 
Gui gui; 

public void setup()
{
  audioContext = new AudioContext();
  size(400, 600);
    smooth();
  frameRate(60);
 
 
  
  //frameRate(99999);
  beatKeeper = new BeatKeeper(90);

 

  RhythmPlayer player1 = new RhythmPlayer();
  player1.setFrequency(3500);
  RhythmPlayer player2 = new RhythmPlayer();
   player2.setFrequency(5000);
  RhythmPlayer player3 = new RhythmPlayer();
   player3.setFrequency(1200);
  //players = new RhythmPlayer[];
  RhythmPlayer[] players = {player1, player2, player3 };
  this.players = players;
//players[0].setActive(false);
  beatKeeper.registerClient(player1);
  beatKeeper.registerClient(player2);
  beatKeeper.registerClient(player3);
  //audioContext.start();
  this.circleVisualizer = new CirclesVisualizer(players,400,400 );

  ColorScheme[] colorSchemes = {new ColorScheme(255,50,160),new ColorScheme(50,200,70),new ColorScheme(80,220,220)};
  this.colorSchemes = colorSchemes;
 
  gui = new Gui(this);
 

}



public void draw()
{
  background(0);
 /*int xCenter = width/2 ;
		int  yCenter = height/2;
		pushMatrix();
		 translate( xCenter, yCenter );*/
		 circleVisualizer.draw();
		/* popMatrix();*/
 
  
}

public void mouseDragged()
{
// code that happens when the mouse moves
// with the button down
}

public void mousePressed()
{
// code that happens when the mouse button
// is pressed
}

public void mouseReleased()
{
// code that happens when the mouse button
// is released
}

public void keyPressed() {
  gui.keyPressed(keyCode);
  
}



public interface BeatClient
{
	public void beat();
	public void registerBeatKeeper( BeatKeeper bp);
	public void setActive(boolean b );
}


public class BeatKeeper extends Bead
{
	
    float interval;

	ArrayList<BeatClient> clients;
	
	Clock clock;


	public  BeatKeeper (int bpm)
	{
		
		 interval = 1000.0f / (bpm * 4/ 60.0f); 
    	 clock = new Clock(audioContext, interval);
		clock.setClick(false);
		 clock.addMessageListener(this);
		 audioContext.out.addDependent(clock);
 		
		this.clients = new ArrayList<BeatClient>(); 
		
	}

	public void setBpm(int bpm)
	{
		 interval = 1000.0f / (bpm * 4/ 60.0f); 
		 clock.getIntervalEnvelope().setValue(interval);
	}

	public void registerClient( BeatClient bc )
	{
		//print(this.clients);
		this.clients.add(bc);
		bc.registerBeatKeeper(this);
	}

	public void sendBeat()
	{
		for(int i = 0; i < this.clients.size(); i++)
		{
			this.clients.get(i).beat();
		}
	}

	public void messageReceived(Bead message) {
        Clock c = (Clock)message;
        if(c.isBeat()) {
          this.sendBeat();
       }
     }

}
class BpmListener implements ControlListener 
{

  PApplet mainApp;
  public BpmListener(PApplet p)
  {
    mainApp = p;
  }
  
  
  public void controlEvent(ControlEvent theEvent) 
  {   
          beatKeeper.setBpm((int) theEvent.getController().getValue());
  }
}
class ChannelListener implements ControlListener
{
	int channel;
	int currBeats, currAccents;

	public ChannelListener(int channel)
	{
		this.channel = channel;

	}
	public RhythmPlayer getCurrentPlayer()
    {
  	return players[this.channel];
    }
	public void controlEvent(ControlEvent theEvent) 
	{   
		if (theEvent.isGroup()) {
			String c = (theEvent.getGroup().getName().substring(3));
			if(c.equals("generator"))
			{
				this.setGenerator( theEvent );
			}
		}
		else 
		{
			
		
	         String c = (theEvent.getController().getName().substring(3));
	         
	         if(c.equals("mute"))
	         {
	         	this.setMute( theEvent );
	         }
	         if(c.equals("solo"))
	         {
	         	this.setSolo( theEvent );
	         }
	         else if(c.equals("beats"))
	         {
	         	this.setBeats( theEvent );
	         }
	         else if(c.equals("accents"))
	         {
	         	this.setAccents( theEvent );
	         }
	          else if(c.equals("freq"))
	         {
	         	this.setFrequency( theEvent );
	         }
	         else if(c.equals("volume"))
	         {
	         	this.setVolume( theEvent );
	         }
	    }
	}

	public void setVolume(ControlEvent theEvent)
	{
		float v = theEvent.getController().getValue();
		this.getCurrentPlayer().setVolume((int) v);
	}
	public void setGenerator(ControlEvent theEvent)
	{
		
		float v = theEvent.getGroup().getValue();
		this.getCurrentPlayer().setGenerator((int) v);
	}

	public void setFrequency(ControlEvent theEvent)
	{
		this.getCurrentPlayer().setFrequency(theEvent.getController().getValue());
	}

	public void setMute(ControlEvent theEvent)
	{

		int val = (int) theEvent.getController().getValue();

	         	if(val == 1)
         		{
         			println(val);
         			this.getCurrentPlayer().setActive(false);
         		}
	         	else  
	         	{
	         		println(val);
	         		this.getCurrentPlayer().setActive(true);
	         	}
	}


	public void setSolo(ControlEvent theEvent)
	{

		int val = (int) theEvent.getController().getValue();

	         	if(val == 1)
         		{
         			for(int i = 0; i < trackNumber;i++)
         			{
         				players[i].setActive((i == this.channel));
         				if(i!=this.channel)
         				{
         				gui.cp5.getController("ch"+i+"solo").setValue(0);
         				}
         			}
         		}
	         	else  
	         	{
	         		for(int i = 0; i < trackNumber;i++)
         			{
         				if(i!=this.channel && (int)gui.cp5.getController("ch"+i+"solo").getValue()==1)
         				{
         					return;
         				}
         				
         			}
         			for(int i = 0; i < trackNumber;i++)
         			{
         				
         				players[i].setActive((int)gui.cp5.getController("ch"+i+"mute").getValue()==0);
         			}
	         	}
	}
	public void setBeats(ControlEvent theEvent)
	{
		this.updatePattern();
		
	}
	public void setAccents(ControlEvent theEvent)
	{
		this.updatePattern();
		
	}

	public Controller getAccentsController()
	{
		return gui.cp5.getController("ch"+channel+"accents");
	}

	public Controller getBeatsController()
	{
		return gui.cp5.getController("ch"+channel+"beats");
	}

	public void updatePattern()
	{
		int beats = (int) this.getBeatsController().getValue();
		int acc = (int) this.getAccentsController().getValue();
		if (beats == this.currBeats && acc == this.currAccents)
		{
			return;
		}
		this.currBeats = beats;
		this.currAccents = acc;

		if(acc > beats )
		{
			this.getAccentsController().setValue(beats);
		}
		this.getAccentsController().setMax(beats);
		this.getCurrentPlayer().setStructure( new EuclideanPattern(acc,beats).getPattern());
	}




}
class CirclesVisualizer
{
	int cvWidth,cvHeight;
	RhythmPlayer[] players;
	public  CirclesVisualizer( RhythmPlayer[] players, int width, int height)
	{
		this.players = players;
		this.cvWidth = width;
		this.cvHeight = height;
		
		  
	}


	public void draw()
	{
		int xCenter = this.cvWidth/2 ;
		int  yCenter = this.cvHeight/2;
		pushMatrix();
		 translate( xCenter, yCenter );
		drawCircles();
		 popMatrix();
		
	}

	public void drawCircles()
	{
		fill(255, 20); //noStroke();
		int xCenter = 0;//width/2 ;
		int  yCenter = 0;//height/2;
		int width = this.cvWidth;
		int height = this.cvHeight;
  		//ellipse( xCenter, yCenter, width* 0.9, height * 0.9);
  		//println("--------");
		for(int i = players.length -1; i >= 0; i--)
		{
			RhythmPlayer currPlayer = players[i];

			ColorScheme cs = colorSchemes[i];
			
			//float mcolor = map(i,0,players.length-1,40,200);

			//println(mcolor);
			int clevel = currPlayer.getCurrentLevel();
			
			//mcolor += 10 * currPlayer.getCurrentLevel();
			fill(cs.getR(),cs.getG(),cs.getB(),100); noStroke();
			//println(mcolor);
				//translate( xCenter,yCenter );
			float currPerc = map(i,0,players.length-1,0.4f,0.8f);
			//println(currPerc);
  			ellipse( xCenter, yCenter, width * 0.8f * currPerc + clevel*20, 0.8f * height * currPerc+ clevel*20);
  			if(currPlayer.isActive())
  			{
  				//println(currPlayer.getPatternLength());
			float d = map(currPlayer.getPointer(), 0, currPlayer.getPatternLength(), 0, radians(360)) - radians(90);
			float dnext = map(currPlayer.getNextPointer(), 0, currPlayer.getPatternLength(), 0, radians(360)) - radians(90);
			
	  			float dx = cos(d)*(width*0.8f*currPerc/2);
	 			float dy = sin(d)*(height*0.8f*currPerc/2);
	 			float dnextx = cos(dnext)*(width*0.8f*currPerc/2);
	 			float dnexty = sin(dnext)*(height*0.8f*currPerc/2);

	 			 fill(120, map(i,0,players.length-1,40,200), map(i,0,players.length-1,40,200),map(clevel,0,currPlayer.getMax(),60,250));
	  			 if(clevel ==  currPlayer.getMax())
	  			 {
	  			 	stroke(255, 150);
	  			 }
	  			 else {
	  			 	 noStroke();
	  			 }
	  			
	  			 triangle(dx, dy, xCenter, yCenter,dnextx, dnexty);
	  			   /*line(dx, dy, xCenter, yCenter);
	  			   line(dnextx, dnexty, xCenter, yCenter);
	  			   line(dx, dy,dnextx, dnexty);*/
	  		}
		}
	}
}
class ColorScheme
{
	int r,g,b;
	public ColorScheme(int r,int g,int b)
	{
		this.r = r;
		this.g = g;
		this.b = b;
	}

	public int getR(){return this.r;}
	public int getG(){return this.g;}
	public int getB(){return this.b;}
}
public class EuclideanPattern 
{
  protected int accents;
  protected int beats;
  public EuclideanPattern(int accents, int beats)
  {
    this.accents =  accents;
    this.beats = beats;
    
  }
  

  public int[] getPattern()
  {
      int[] res = this.eucProcess();
      return res;
  }

public int[] concat(int[] A, int[] B)
{
  int aLen = A.length;
   int bLen = B.length;
   int[] C= new int[aLen+bLen];
   System.arraycopy(A, 0, C, 0, aLen);
   System.arraycopy(B, 0, C, aLen, bLen);
   return C;
}

public int[]  eucProcess()
{
  int silent = this.beats - this.accents;
  int[] U = {1}; 
  int[] Z = {0};
 // var alpha = hits; var beta = silent;
  int[] res = this.euclid(this.accents, U, silent, Z);
  return res;
}

public int[]  euclid(int alpha, int U[], int beta, int[] Z)
{
 //int remainder = null;
  
  if( beta <= 1){ return eucMultiplyConcat(alpha, U, beta, Z);}
  if( alpha >= beta )
  {
   
    return euclid(beta, eucMultiplyConcat(1,U,1,Z), alpha-beta, U);
   // return euclid(beta, U.concat(Z), alpha-beta, U);
  }
  else
  {
     return euclid(alpha, this.concat(U,Z), beta - alpha, Z);
 //   return euclid(alpha, U.concat(Z), beta - alpha, Z);
    //return euclid(alpha, U.concat(Z), beta - alpha, Z);
  }
}

public int[]  eucMultiplyConcat(int alpha, int U[], int beta, int[] Z)
{
  int[] ret = {};
 
  for(int i= 0; i< alpha; i++ )
  {
   // ret = ret.concat(U);
	  ret = this.concat(ret, U);
  }
  for(int i= 0; i< beta; i++ )
  {
    //ret = ret.concat(Z);
	  ret = this.concat(ret, Z);
  }
  ret[0]++;
  return ret;
  
}
  
  
  
}


public class Gui implements ControlListener 
{

	ControlP5 cp5;
	Knob knobBpm;
    PApplet mainApp;
    int maxBeats = 16;
    int bpmMin = 20;
    int bpmMax = 240;
    int freqMin = 30;
    int freqMax = 3000;
	public Gui(PApplet p)
	{
        mainApp = p;
		cp5 = new ControlP5(p);
		 this.addControls();
	}

	public void addControls()
	{

	knobBpm = cp5.addKnob("BPM")
               .setRange(this.bpmMin,this.bpmMax)
               .setValue(90)
               .setPosition(320,330)
               .setRadius(30)
               .setDragDirection(Knob.VERTICAL).setDecimalPrecision(0)
               ;
    cp5.addBang("randomize")
     .setPosition(20, 375)
     .setSize(15, 15)
     .setTriggerEvent(Bang.RELEASE)
     .setLabel("randomize!")
     ;
     cp5.addToggle("play")
     .setPosition(80, 375)
     .setSize(15, 15)
     .setLabel("play [spacebar]").addListener(this)
     ;
    
    cp5.getController("BPM").addListener(new BpmListener(this.mainApp));
    cp5.getController("randomize").addListener(this);
    for(int track = 0; track < trackNumber; track++)
        {
            this.addTrackControls(track);
        }
    
    }
    
    public void addTrackControls(int track)
    {
        int oneBasedIndex = track + 1;
        int controlsWidth = 80;
        int controlsLeftMargin = 5;
        ChannelListener chListener = new ChannelListener(track);
        Group g = cp5.addGroup("ch"+track)
                .setPosition(10 + 100*track,10)
                .setBackgroundHeight(300)
                .setBackgroundColor(color(colorSchemes[track].getR(),colorSchemes[track].getG(),colorSchemes[track].getB(),50))
                .setColorBackground(color(colorSchemes[track].getR(),colorSchemes[track].getG(),colorSchemes[track].getB(),150))
                .setColorActive(color(colorSchemes[track].getR(),colorSchemes[track].getG(),colorSchemes[track].getB(),250))
                .close().setCaptionLabel("CH"+oneBasedIndex);
                ;
        cp5.addToggle("ch"+track+"mute")
         .setPosition(controlsLeftMargin,15)
         .setSize(10,10).setValue(false).setCaptionLabel("mute")
         .setGroup(g).addListener(chListener)
         ;

         cp5.addToggle("ch"+track+"solo")
         .setPosition(controlsLeftMargin+45,15)
         .setSize(10,10).setValue(false).setCaptionLabel("solo")
         .setGroup(g).addListener(chListener)
         ;
        //random initial values
        int randomBeat = (int)random(3,maxBeats) ;

        int randomAcc = (int)random(1,randomBeat -1 ) ;
        cp5.addNumberbox("ch"+track+"beats")
             .setPosition(controlsLeftMargin,90)
             .setSize(controlsWidth,14).setDecimalPrecision(0)
             .setScrollSensitivity(0).setRange(1,maxBeats).setCaptionLabel("BEATS")
             .setValue(randomBeat).setGroup(g).addListener(chListener)
             ;
        cp5.addNumberbox("ch"+track+"accents")
             .setPosition(controlsLeftMargin,50)
             .setSize(controlsWidth,14).setDecimalPrecision(0)
             .setScrollSensitivity(0).setRange(1,maxBeats).setCaptionLabel("ACCENTS")
             .setValue(randomAcc).setGroup(g).addListener(chListener)
             ;
       
        players[track].setStructure( new EuclideanPattern(randomAcc,randomBeat).getPattern());

        cp5.addKnob("ch"+track+"volume")
               .setRange(0,100)
               .setValue(50).setGroup(g).addListener(chListener)
               .setPosition(controlsLeftMargin+20,230)
               .setRadius(20).setCaptionLabel("volume")
               .setDragDirection(Knob.VERTICAL).setDecimalPrecision(0)
               ;

        int randomFreq = (int)random(100,5000);
        cp5.addKnob("ch"+track+"freq")
               .setRange(this.freqMin,this.freqMax)
               .setValue(randomFreq).setGroup(g).addListener(chListener)
               .setPosition(controlsLeftMargin+20,130)
               .setRadius(20).setCaptionLabel("freq")
               .setDragDirection(Knob.VERTICAL).setDecimalPrecision(0)
               ;
        players[track].setFrequency(randomFreq);
        DropdownList dl = cp5.addDropdownList("ch"+track+"generator")
          .setPosition(controlsLeftMargin, 210).setGroup(g).addListener(chListener)
          .setWidth(controlsWidth).setCaptionLabel("SOUND")
          
          ;
        dl.addItem("NOISE", RhythmPlayer.NOISE);
        dl.addItem("SINE", RhythmPlayer.SINE);
        dl.addItem("SAW", RhythmPlayer.SAW);
        dl.addItem("SQUARE", RhythmPlayer.SQUARE);
        dl.setIndex(1);

         
        
    }

public void controlEvent(ControlEvent theEvent) 
    {   
        String c = (theEvent.getController().getName());
        if(c.equals("randomize"))
        {
          this.randomizePars();
        }
        else if( c.equals("play") )
        {
            if(audioContext.isRunning())
            {
                audioContext.stop();
            }
            else{
                audioContext.start();
            }
        }
    }

public void randomizePars()
      {

         int randomBpm = (int)random(this.bpmMin,this.bpmMax) ;
         cp5.getController("BPM").setValue(randomBpm);
        for(int track = 0; track < trackNumber; track++)
        {
            //create a random pattern
            int randomBeat = (int)random(3,maxBeats) ;
            int randomAcc = (int)random(1,randomBeat -1 ) ;
            cp5.getController("ch"+track+"beats").setValue(randomBeat);
            cp5.getController("ch"+track+"accents").setValue(randomAcc);
            cp5.getController("ch"+track+"volume").setValue((int)random(100));
            cp5.getController("ch"+track+"freq").setValue((int)random(this.freqMin,this.freqMax));
            DropdownList dl = (DropdownList)cp5.getGroup("ch"+track+"generator");
            int gen = (int)random(1,4);
            dl.setValue(gen);
            players[track].setGenerator(gen);
        }

            
      }

    public void keyPressed(int keyCode) {
         //println(keyCode);
      switch(keyCode){
        case 82://r
           this.randomizePars();break;
        case 32:
            Toggle play = (Toggle)cp5.getController("play");
            play.toggle();
            
            
        break;
       
      }
    }

}


//The MIT License (MIT)

//Copyright (c) 2013 Mick Grierson, Matthew Yee-King, Marco Gillies

//Permission is hereby granted, free of charge, to any person obtaining a copy\u2028of this software and associated documentation files (the "Software"), to deal\u2028in the Software without restriction, including without limitation the rights\u2028to use, copy, modify, merge, publish, distribute, sublicense, and/or sell\u2028copies of the Software, and to permit persons to whom the Software is\u2028furnished to do so, subject to the following conditions:
//The above copyright notice and this permission notice shall be included in\u2028all copies or substantial portions of the Software.

//THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR\u2028IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,\u2028FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE\u2028AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER\u2028LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,\u2028OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN\u2028THE SOFTWARE.

















 
 
 
 

//import android.content.res.Resources;
// import android.app.Activity; 
// import android.os.Bundle; 
// import android.media.*;
// import android.media.audiofx.Visualizer;
// import android.content.res.AssetFileDescriptor;
// import android.hardware.*;


public class Maxim {

    private float sampleRate;

    public final float[] mtof = {
	0f, 8.661957f, 9.177024f, 9.722718f, 10.3f, 10.913383f, 11.562325f, 12.25f, 12.978271f, 13.75f, 14.567617f, 15.433853f, 16.351599f, 17.323914f, 18.354048f, 19.445436f, 20.601723f, 21.826765f, 23.124651f, 24.5f, 25.956543f, 27.5f, 29.135235f, 30.867706f, 32.703197f, 34.647827f, 36.708096f, 38.890873f, 41.203445f, 43.65353f, 46.249302f, 49.f, 51.913086f, 55.f, 58.27047f, 61.735413f, 65.406395f, 69.295654f, 73.416191f, 77.781746f, 82.406891f, 87.30706f, 92.498604f, 97.998856f, 103.826172f, 110.f, 116.540939f, 123.470825f, 130.81279f, 138.591309f, 146.832382f, 155.563492f, 164.813782f, 174.61412f, 184.997208f, 195.997711f, 207.652344f, 220.f, 233.081879f, 246.94165f, 261.62558f, 277.182617f, 293.664764f, 311.126984f, 329.627563f, 349.228241f, 369.994415f, 391.995422f, 415.304688f, 440.f, 466.163757f, 493.883301f, 523.25116f, 554.365234f, 587.329529f, 622.253967f, 659.255127f, 698.456482f, 739.988831f, 783.990845f, 830.609375f, 880.f, 932.327515f, 987.766602f, 1046.502319f, 1108.730469f, 1174.659058f, 1244.507935f, 1318.510254f, 1396.912964f, 1479.977661f, 1567.981689f, 1661.21875f, 1760.f, 1864.655029f, 1975.533203f, 2093.004639f, 2217.460938f, 2349.318115f, 2489.015869f, 2637.020508f, 2793.825928f, 2959.955322f, 3135.963379f, 3322.4375f, 3520.f, 3729.31f, 3951.066406f, 4186.009277f, 4434.921875f, 4698.63623f, 4978.031738f, 5274.041016f, 5587.651855f, 5919.910645f, 6271.926758f, 6644.875f, 7040.f, 7458.620117f, 7902.132812f, 8372.018555f, 8869.84375f, 9397.272461f, 9956.063477f, 10548.082031f, 11175.303711f, 11839.821289f, 12543.853516f, 13289.75f
    };

    private AudioThread audioThread;
    private PApplet processing;

    public Maxim (PApplet processing) {
	this.processing = processing;
	sampleRate = 44100f;
	audioThread = new AudioThread(sampleRate, 4096, false);
	audioThread.start();
	    
    }

    public float[] getPowerSpectrum() {
	return audioThread.getPowerSpectrum();
    }

    /** 
     *  load the sent file into an audio player and return it. Use
     *  this if your audio file is not too long want precision control
     *  over looping and play head position
     * @param String filename - the file to load
     * @return AudioPlayer - an audio player which can play the file
     */
    public AudioPlayer loadFile(String filename) {
	// this will load the complete audio file into memory
	AudioPlayer ap = new AudioPlayer(filename, sampleRate, processing);
	audioThread.addAudioGenerator(ap);
	// now we need to tell the audiothread
	// to ask the audioplayer for samples
	return ap;
    }

    /**
     * Create a wavetable player object with a wavetable of the sent
     * size. Small wavetables (<128) make for a 'nastier' sound!
     * 
     */
    public WavetableSynth createWavetableSynth(int size) {
	// this will load the complete audio file into memory
	WavetableSynth ap = new WavetableSynth(size, sampleRate);
	audioThread.addAudioGenerator(ap);
	// now we need to tell the audiothread
	// to ask the audioplayer for samples
	return ap;
    }
    // /**
    //  * Create an AudioStreamPlayer which can stream audio from the
    //  * internet as well as local files.  Does not provide precise
    //  * control over looping and playhead like AudioPlayer does.  Use this for
    //  * longer audio files and audio from the internet.
    //  */
    // public AudioStreamPlayer createAudioStreamPlayer(String url) {
    //     AudioStreamPlayer asp = new AudioStreamPlayer(url);
    //     return asp;
    // }
}




/**
 * This class can play audio files and includes an fx chain 
 */
public class AudioPlayer implements Synth, AudioGenerator {
    private FXChain fxChain;
    private boolean isPlaying;
    private boolean isLooping;
    private boolean analysing;
    private FFT fft;
    private int fftInd;
    private float[] fftFrame;
    private float[] powerSpectrum;

    //private float startTimeSecs;
    //private float speed;
    private int length;
    private short[] audioData;
    private float startPos;
    private float readHead;
    private float dReadHead;
    private float sampleRate;
    private float masterVolume;

    float x1, x2, y1, y2, x3, y3;

    public AudioPlayer(float sampleRate) {
	fxChain = new FXChain(sampleRate);
	this.sampleRate = sampleRate;
    }

    public AudioPlayer (String filename, float sampleRate, PApplet processing) {
	//super(filename);
	this(sampleRate);
	try {
	    // how long is the file in bytes?
	    //long byteCount = getAssets().openFd(filename).getLength();
	    File f = new File(processing.dataPath(filename));
	    long byteCount = f.length();
	    //System.out.println("bytes in "+filename+" "+byteCount);

	    // check the format of the audio file first!
	    // only accept mono 16 bit wavs
	    //InputStream is = getAssets().open(filename); 
	    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(f));

	    // chop!!

	    int bitDepth;
	    int channels;
	    boolean isPCM;
	    // allows us to read up to 4 bytes at a time 
	    byte[] byteBuff = new byte[4];

	    // skip 20 bytes to get file format
	    // (1 byte)
	    bis.skip(20);
	    bis.read(byteBuff, 0, 2); // read 2 so we are at 22 now
	    isPCM = ((short)byteBuff[0]) == 1 ? true:false; 
	    //System.out.println("File isPCM "+isPCM);

	    // skip 22 bytes to get # channels
	    // (1 byte)
	    bis.read(byteBuff, 0, 2);// read 2 so we are at 24 now
	    channels = (short)byteBuff[0];
	    //System.out.println("#channels "+channels+" "+byteBuff[0]);
	    // skip 24 bytes to get sampleRate
	    // (32 bit int)
	    bis.read(byteBuff, 0, 4); // read 4 so now we are at 28
	    sampleRate = bytesToInt(byteBuff, 4);
	    //System.out.println("Sample rate "+sampleRate);
	    // skip 34 bytes to get bits per sample
	    // (1 byte)
	    bis.skip(6); // we were at 28...
	    bis.read(byteBuff, 0, 2);// read 2 so we are at 36 now
	    bitDepth = (short)byteBuff[0];
	    //System.out.println("bit depth "+bitDepth);
	    // convert to word count...
	    bitDepth /= 8;
	    // now start processing the raw data
	    // data starts at byte 36
	    int sampleCount = (int) ((byteCount - 36) / (bitDepth * channels));
	    audioData = new short[sampleCount];
	    int skip = (channels -1) * bitDepth;
	    int sample = 0;
	    // skip a few sample as it sounds like shit
	    bis.skip(bitDepth * 4);
	    while (bis.available () >= (bitDepth+skip)) {
		bis.read(byteBuff, 0, bitDepth);// read 2 so we are at 36 now
		//int val = bytesToInt(byteBuff, bitDepth);
		// resample to 16 bit by casting to a short
		audioData[sample] = (short) bytesToInt(byteBuff, bitDepth);
		bis.skip(skip);
		sample ++;
	    }

	    float secs = (float)sample / (float)sampleRate;
	    //System.out.println("Read "+sample+" samples expected "+sampleCount+" time "+secs+" secs ");      
	    bis.close();


	    // unchop
	    readHead = 0;
	    startPos = 0;
	    // default to 1 sample shift per tick
	    dReadHead = 1;
	    isPlaying = false;
	    isLooping = true;
	    masterVolume = 1;
	} 
	catch (FileNotFoundException e) {

	    e.printStackTrace();
	}
	catch (IOException e) {
	    e.printStackTrace();
	}
    }

    public void setAnalysing(boolean analysing_) {
	this.analysing = analysing_;
	if (analysing) {// initialise the fft
	    fft = new FFT();
	    fftInd = 0;
	    fftFrame = new float[1024];
	    powerSpectrum = new float[fftFrame.length/2];
	}
    }

    public float getAveragePower() {
	if (analysing) {
	    // calc the average
	    float sum = 0;
	    for (int i=0;i<powerSpectrum.length;i++){
		sum += powerSpectrum[i];
	    }
	    sum /= powerSpectrum.length;
	    return sum;
	}
	else {
	    System.out.println("call setAnalysing to enable power analysis");
	    return 0;
	}
    }
    public float[] getPowerSpectrum() {
	if (analysing) {
	    return powerSpectrum;
	}
	else {
	    System.out.println("call setAnalysing to enable power analysis");
	    return null;
	}
    }

    /** 
     *convert the sent byte array into an int. Assumes little endian byte ordering. 
     *@param bytes - the byte array containing the data
     *@param wordSizeBytes - the number of bytes to read from bytes array
     *@return int - the byte array as an int
     */
    private int bytesToInt(byte[] bytes, int wordSizeBytes) {
	int val = 0;
	for (int i=wordSizeBytes-1; i>=0; i--) {
	    val <<= 8;
	    val |= (int)bytes[i] & 0xFF;
	}
	return val;
    }

    /**
     * Test if this audioplayer is playing right now
     * @return true if it is playing, false otherwise
     */
    public boolean isPlaying() {
	return isPlaying;
    }

    /**
     * Set the loop mode for this audio player
     * @param looping 
     */
    public void setLooping(boolean looping) {
	isLooping = looping;
    }

    /**
     * Move the start pointer of the audio player to the sent time in ms
     * @param timeMs - the time in ms
     */
    public void cue(int timeMs) {
	//startPos = ((timeMs / 1000) * sampleRate) % audioData.length;
	//readHead = startPos;
	//System.out.println("AudioPlayer Cueing to "+timeMs);
	if (timeMs >= 0) {// ignore crazy values
	    readHead = (((float)timeMs / 1000f) * sampleRate) % audioData.length;
	    //System.out.println("Read head went to "+readHead);
	}
    }

    /**
     *  Set the playback speed,
     * @param speed - playback speed where 1 is normal speed, 2 is double speed
     */
    public void speed(float speed) {
	//System.out.println("setting speed to "+speed);
	dReadHead = speed;
    }

    /**
     * Set the master volume of the AudioPlayer
     */

    public void volume(float volume) {
	masterVolume = volume;
    }

    /**
     * Get the length of the audio file in samples
     * @return int - the  length of the audio file in samples
     */
    public int getLength() {
	return audioData.length;
    }
    /**
     * Get the length of the sound in ms, suitable for sending to 'cue'
     */
    public float getLengthMs() {
	return ((float) audioData.length / sampleRate * 1000f);
    }

    /**
     * Start playing the sound. 
     */
    public void play() {
	isPlaying = true;
    }

    /**
     * Stop playing the sound
     */
    public void stop() {
	isPlaying = false;
    }

    /**
     * implementation of the AudioGenerator interface
     */
    public short getSample() {
	if (!isPlaying) {
	    return 0;
	}
	else {
	    short sample;
	    readHead += dReadHead;
	    if (readHead > (audioData.length - 1)) {// got to the end
		//% (float)audioData.length;
		if (isLooping) {// back to the start for loop mode
		    readHead = readHead % (float)audioData.length;
		}
		else {
		    readHead = 0;
		    isPlaying = false;
		}
	    }

	    // linear interpolation here
	    // declaring these at the top...
	    // easy to understand version...
	    //      float x1, x2, y1, y2, x3, y3;
	    x1 = floor(readHead);
	    x2 = x1 + 1;
	    y1 = audioData[(int)x1];
	    y2 = audioData[(int) (x2 % audioData.length)];
	    x3 = readHead;
	    // calc 
	    y3 =  y1 + ((x3 - x1) * (y2 - y1));
	    y3 *= masterVolume;
	    sample = fxChain.getSample((short) y3);
	    if (analysing) {
		// accumulate samples for the fft
		fftFrame[fftInd] = (float)sample / 32768f;
		fftInd ++;
		if (fftInd == fftFrame.length - 1) {// got a frame
		    powerSpectrum = fft.process(fftFrame, true);
		    fftInd = 0;
		}
	    }

	    //return sample;
	    return (short)y3;
	}
    }

    public void setAudioData(short[] audioData) {
	this.audioData = audioData;
    }

    public short[] getAudioData() {
	return audioData;
    }

    public void setDReadHead(float dReadHead) {
	this.dReadHead = dReadHead;
    }

    ///
    //the synth interface
    // 

    public void ramp(float val, float timeMs) {
	fxChain.ramp(val, timeMs);
    } 



    public void setDelayTime(float delayMs) {
	fxChain.setDelayTime( delayMs);
    }

    public void setDelayFeedback(float fb) {
	fxChain.setDelayFeedback(fb);
    }

    public void setFilter(float cutoff, float resonance) {
	fxChain.setFilter( cutoff, resonance);
    }
}

/**
 * This class can play wavetables and includes an fx chain
 */
public class WavetableSynth extends AudioPlayer {

    private short[] sine;
    private short[] saw;
    private short[] wavetable;
    private float sampleRate;

    public WavetableSynth(int size, float sampleRate) {
	super(sampleRate);
	sine = new short[size];
	for (float i = 0; i < sine.length; i++) {
	    float phase;
	    phase = TWO_PI / size * i;
	    sine[(int)i] = (short) (sin(phase) * 32768);
	}
	saw = new short[size];
	for (float i = 0; i<saw.length; i++) {
	    saw[(int)i] = (short) (i / (float)saw.length *32768);
	}

	this.sampleRate = sampleRate;
	setAudioData(sine);
	setLooping(true);
    }

    public void setFrequency(float freq) {
	if (freq > 0) {
	    //System.out.println("freq freq "+freq);
	    setDReadHead((float)getAudioData().length / sampleRate * freq);
	}
    }

    public void loadWaveForm(float[] wavetable_) {
	if (wavetable == null || wavetable_.length != wavetable.length) {
	    // only reallocate if there is a change in length
	    wavetable = new short[wavetable_.length];
	}
	for (int i=0;i<wavetable.length;i++) {
	    wavetable[i] = (short) (wavetable_[i] * 32768);
	}
	setAudioData(wavetable);
    }
}

public interface Synth {
    public void volume(float volume);
    public void ramp(float val, float timeMs);  
    public void setDelayTime(float delayMs);  
    public void setDelayFeedback(float fb);  
    public void setFilter(float cutoff, float resonance);
    public void setAnalysing(boolean analysing);
    public float getAveragePower();
    public float[] getPowerSpectrum();
}

public class AudioThread extends Thread
{
    private int minSize;
    //private AudioTrack track;
    private short[] bufferS;
    private byte[] bOutput;
    private ArrayList audioGens;
    private boolean running;

    private FFT fft;
    private float[] fftFrame;
    private SourceDataLine sourceDataLine;
    private int blockSize;

    public AudioThread(float samplingRate, int blockSize) {
	this(samplingRate, blockSize, false);
    }

    public AudioThread(float samplingRate, int blockSize, boolean enableFFT)
    {
	this.blockSize = blockSize;
	audioGens = new ArrayList();
	// we'll do our dsp in shorts
	bufferS = new short[blockSize];
	// but we'll convert to bytes when sending to the sound card
	bOutput = new byte[blockSize * 2];
	AudioFormat audioFormat = new AudioFormat(samplingRate, 16, 1, true, false);
	DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class, audioFormat);
	    
	sourceDataLine = null;
	// here we try to initialise the audio system. try catch is exception handling, i.e. 
	// dealing with things not working as expected
	try {
	    sourceDataLine = (SourceDataLine) AudioSystem.getLine(dataLineInfo);
	    sourceDataLine.open(audioFormat, bOutput.length);
	    sourceDataLine.start();
	    running = true;
	} catch (LineUnavailableException lue) {
	    // it went wrong!
	    lue.printStackTrace(System.err);
	    System.out.println("Could not initialise audio. check above stack trace for more info");
	    //System.exit(1);
	}


	if (enableFFT) {
	    try {
		fft = new FFT();
	    }
	    catch(Exception e) {
		System.out.println("Error setting up the audio analyzer");
		e.printStackTrace();
	    }
	}
    }

    // overidden from Thread
    public void run() {
	running = true;
	while (running) {
	    //System.out.println("AudioThread : ags  "+audioGens.size());
	    for (int i=0;i<bufferS.length;i++) {
		// we add up using a 32bit int
		// to prevent clipping
		int val = 0;
		if (audioGens.size() > 0) {
		    for (int j=0;j<audioGens.size(); j++) {
			AudioGenerator ag = (AudioGenerator)audioGens.get(j);
			val += ag.getSample();
		    }
		    val /= audioGens.size();
		}
		bufferS[i] = (short) val;
	    }
	    // send it to the audio device!
	    sourceDataLine.write(shortsToBytes(bufferS, bOutput), 0, bOutput.length);
	}
    }
	
    public void addAudioGenerator(AudioGenerator ag) {
	audioGens.add(ag);
    }

    /**
     * converts an array of 16 bit samples to bytes
     * in little-endian (low-byte, high-byte) format.
     */
    private byte[] shortsToBytes(short[] sData, byte[] bData) {
	int index = 0;
	short sval;
	for (int i = 0; i < sData.length; i++) {
	    //short sval = (short) (fData[j][i] * ShortMaxValueAsFloat);
	    sval = sData[i];
	    bData[index++] = (byte) (sval & 0x00FF);
	    bData[index++] = (byte) ((sval & 0xFF00) >> 8);
	}
	return bData;
    }

    /**
     * Returns a recent snapshot of the power spectrum 
     */
    public float[] getPowerSpectrum() {
	// process the last buffer that was calculated
	if (fftFrame == null) {
	    fftFrame = new float[bufferS.length];
	}
	for (int i=0;i<fftFrame.length;i++) {
	    fftFrame[i] = ((float) bufferS[i] / 32768f);
	}
	return fft.process(fftFrame, true);
	//return powerSpectrum;
    }
}

/**
 * Implement this interface so the AudioThread can request samples from you
 */
public interface AudioGenerator {
    /** AudioThread calls this when it wants a sample */
    public short getSample();
}


public class FXChain  {
    private float currentAmp;
    private float dAmp;
    private float targetAmp;
    private boolean goingUp;
    private Filter filter;

    private float[] dLine;   

    private float sampleRate;

    public FXChain(float sampleRate_) {
	sampleRate = sampleRate_;
	currentAmp = 1;
	dAmp = 0;
	// filter = new MickFilter(sampleRate);
	filter = new RLPF(sampleRate);

	//filter.setFilter(0.1, 0.1);
    }

    public void ramp(float val, float timeMs) {
	// calc the dAmp;
	// - change per ms
	targetAmp = val;
	dAmp = (targetAmp - currentAmp) / (timeMs / 1000 * sampleRate);
	if (targetAmp > currentAmp) {
	    goingUp = true;
	}
	else {
	    goingUp = false;
	}
    }


    public void setDelayTime(float delayMs) {
    }

    public void setDelayFeedback(float fb) {
    }

    public void volume(float volume) {
    }


    public short getSample(short input) {
	float in;
	in = (float) input / 32768;// -1 to 1

	in =  filter.applyFilter(in);
	if (goingUp && currentAmp < targetAmp) {
	    currentAmp += dAmp;
	}
	else if (!goingUp && currentAmp > targetAmp) {
	    currentAmp += dAmp;
	}  

	if (currentAmp > 1) {
	    currentAmp = 1;
	}
	if (currentAmp < 0) {
	    currentAmp = 0;
	}  
	in *= currentAmp;  
	return (short) (in * 32768);
    }

    public void setFilter(float f, float r) {
	filter.setFilter(f, r);
    }
}


// /**
//  * Represents an audio source is streamed as opposed to being completely loaded (as WavSource is)
//  */
// public class AudioStreamPlayer {
// 	/** a class from the android API*/
// 	private MediaPlayer mediaPlayer;
// 	/** a class from the android API*/
// 	private Visualizer viz; 
// 	private byte[] waveformBuffer;
// 	private byte[] fftBuffer;
// 	private byte[] powerSpectrum;

// 	/**
// 	 * create a stream source from the sent url 
// 	 */
// 	public AudioStreamPlayer(String url) {
// 	    try {
// 		mediaPlayer = new MediaPlayer();
// 		//mp.setAuxEffectSendLevel(1);
// 		mediaPlayer.setLooping(true);

// 		// try to parse the URL... if that fails, we assume it
// 		// is a local file in the assets folder
// 		try {
// 		    URL uRL = new URL(url);
// 		    mediaPlayer.setDataSource(url);
// 		}
// 		catch (MalformedURLException eek) {
// 		    // couldn't parse the url, assume its a local file
// 		    AssetFileDescriptor afd = getAssets().openFd(url);
// 		    //mp.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
// 		    mediaPlayer.setDataSource(afd.getFileDescriptor());
// 		    afd.close();
// 		}

// 		mediaPlayer.prepare();
// 		//mediaPlayer.start();
// 		//System.out.println("Created audio with id "+mediaPlayer.getAudioSessionId());
// 		viz = new Visualizer(mediaPlayer.getAudioSessionId());
// 		viz.setEnabled(true);
// 		waveformBuffer = new byte[viz.getCaptureSize()];
// 		fftBuffer = new byte[viz.getCaptureSize()/2];
// 		powerSpectrum = new byte[viz.getCaptureSize()/2];
// 	    }
// 	    catch (Exception e) {
// 		System.out.println("StreamSource could not be initialised. Check url... "+url+ " and that you have added the permission INTERNET, RECORD_AUDIO and MODIFY_AUDIO_SETTINGS to the manifest,");
// 		e.printStackTrace();
// 	    }
// 	}

// 	public void play() {
// 	    mediaPlayer.start();
// 	}

// 	public int getLengthMs() {
// 	    return mediaPlayer.getDuration();
// 	}

// 	public void cue(float timeMs) {
// 	    if (timeMs >= 0 && timeMs < getLengthMs()) {// ignore crazy values
// 		mediaPlayer.seekTo((int)timeMs);
// 	    }
// 	}

// 	/**
// 	 * Returns a recent snapshot of the power spectrum as 8 bit values
// 	 */
// 	public byte[] getPowerSpectrum() {
// 	    // calculate the spectrum
// 	    viz.getFft(fftBuffer);
// 	    short real, imag;
// 	    for (int i=2;i<fftBuffer.length;i+=2) {
// 		real = (short) fftBuffer[i];
// 		imag = (short) fftBuffer[i+1];
// 		powerSpectrum[i/2] = (byte) ((real * real)  + (imag * imag));
// 	    }
// 	    return powerSpectrum;
// 	}

// 	/**
// 	 * Returns a recent snapshot of the waveform being played 
// 	 */
// 	public byte[] getWaveForm() {
// 	    // retrieve the waveform
// 	    viz.getWaveForm(waveformBuffer);
// 	    return waveformBuffer;
// 	}
// } 

/**
 * Use this class to retrieve data about the movement of the device
 */
public class Accelerometer  {
    //private SensorManager sensorManager;
    //private Sensor accelerometer;
    private float[] values;

    public Accelerometer() {
	//sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
	//accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
	//sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
	values = new float[3];
	System.out.println("Java accelerometer will generate values of zero!");
    }

    public float[] getValues() {
	return values;
    }

    public float getX() {
	return values[0];
    }

    public float getY() {
	return values[1];
    }

    public float getZ() {
	return values[2];
    }

}

public interface Filter {
    public void setFilter(float f, float r);
    public float applyFilter(float in);
}

/** https://github.com/supercollider/supercollider/blob/master/server/plugins/FilterUGens.cpp */

public class RLPF implements Filter {
    float a0, b1, b2, y1, y2;
    float freq;
    float reson;
    float sampleRate;
    boolean changed;

    public RLPF(float sampleRate_) {
	this.sampleRate = sampleRate_;
	reset();
	this.setFilter(sampleRate / 4, 0.01f);
    }
    private void reset() {
	a0 = 0.f;
	b1 = 0.f;
	b2 = 0.f;
	y1 = 0.f;
	y2 = 0.f;
    }
    /** f is in the range 0-sampleRate/2 */
    public void setFilter(float f, float r) {
	// constrain 
	// limit to 0-1 
	f = constrain(f, 0, sampleRate/4);
	r = constrain(r, 0, 1);
	// invert so high r -> high resonance!
	r = 1-r;
	// remap to appropriate ranges
	f = map(f, 0f, sampleRate/4, 30f, sampleRate / 4);
	r = map(r, 0f, 1f, 0.005f, 2f);

	System.out.println("rlpf: f "+f+" r "+r);

	this.freq = f * TWO_PI / sampleRate;
	this.reson = r;
	changed = true;
    }

    public float applyFilter(float in) {
	float y0;
	if (changed) {
	    float D = tan(freq * reson * 0.5f);
	    float C = ((1.f-D)/(1.f+D));
	    float cosf = cos(freq);
	    b1 = (1.f + C) * cosf;
	    b2 = -C;
	    a0 = (1.f + C - b1) * .25f;
	    changed = false;
	}
	y0 = a0 * in + b1 * y1 + b2 * y2;
	y2 = y1;
	y1 = y0;
	if (Float.isNaN(y0)) {
	    reset();
	}
	return y0;
    }
}

/** https://github.com/micknoise/Maximilian/blob/master/maximilian.cpp */

class MickFilter implements Filter {

    private float f, res;
    private float cutoff, z, c, x, y, out;
    private float sampleRate;

    MickFilter(float sampleRate) {
	this.sampleRate = sampleRate;
    }

    public void setFilter(float f, float r) {
	f = constrain(f, 0, 1);
	res = constrain(r, 0, 1);
	f = map(f, 0, 1, 25, sampleRate / 4);
	r = map(r, 0, 1, 1, 25);
	this.f = f;
	this.res = r;    

	//System.out.println("mickF: f "+f+" r "+r);
    }
    public float applyFilter(float in) {
	return lores(in, f, res);
    }

    public float lores(float input, float cutoff1, float resonance) {
	//cutoff=cutoff1*0.5;
	//if (cutoff<10) cutoff=10;
	//if (cutoff>(sampleRate*0.5)) cutoff=(sampleRate*0.5);
	//if (resonance<1.) resonance = 1.;

	//if (resonance>2.4) resonance = 2.4;
	z=cos(TWO_PI*cutoff/sampleRate);
	c=2-2*z;
	float r=(sqrt(2.0f)*sqrt(-pow((z-1.0f), 3.0f))+resonance*(z-1))/(resonance*(z-1));
	x=x+(input-y)*c;
	y=y+x;
	x=x*r;
	out=y;
	return out;
    }
}


/*
 * This file is part of Beads. See http://www.beadsproject.net for all information.
 * CREDIT: This class uses portions of code taken from MPEG7AudioEnc. See readme/CREDITS.txt.
 */

/**
 * FFT performs a Fast Fourier Transform and forwards the complex data to any listeners. 
 * The complex data is a float of the form float[2][frameSize], with real and imaginary 
 * parts stored respectively.
 * 
 * @beads.category analysis
 */
public class FFT {

    /** The real part. */
    protected float[] fftReal;

    /** The imaginary part. */
    protected float[] fftImag;

    private float[] dataCopy = null;
    private float[][] features;
    private float[] powers;
    private int numFeatures;

    /**
     * Instantiates a new FFT.
     */
    public FFT() {
	features = new float[2][];
    }

    /* (non-Javadoc)
     * @see com.olliebown.beads.core.UGen#calculateBuffer()
     */
    public float[] process(float[] data, boolean direction) {
	if (powers == null) powers = new float[data.length/2];
	if (dataCopy==null || dataCopy.length!=data.length)
	    dataCopy = new float[data.length];
	System.arraycopy(data, 0, dataCopy, 0, data.length);

	fft(dataCopy, dataCopy.length, direction);
	numFeatures = dataCopy.length;
	fftReal = calculateReal(dataCopy, dataCopy.length);
	fftImag = calculateImaginary(dataCopy, dataCopy.length);
	features[0] = fftReal;
	features[1] = fftImag;
	// now calc the powers
	return specToPowers(fftReal, fftImag, powers);
    }

    public float[] specToPowers(float[] real, float[] imag, float[] powers) {
	float re, im;
	double pow;
	for (int i=0;i<powers.length;i++) {
	    //real = spectrum[i][j].re();
	    //imag = spectrum[i][j].im();
	    re = real[i];
	    im = imag[i];
	    powers[i] = (re*re + im * im);
	    powers[i] = (float) Math.sqrt(powers[i]) / 10;
	    // convert to dB
	    pow = (double) powers[i];
	    powers[i] = (float)(10 *  Math.log10(pow * pow)); // (-100 - 100)
	    powers[i] = (powers[i] + 100) * 0.005f; // 0-1
	}
	return powers;
    }

    /**
     * The frequency corresponding to a specific bin 
     * 
     * @param samplingFrequency The Sampling Frequency of the AudioContext
     * @param blockSize The size of the block analysed
     * @param binNumber 
     */
    public  float binFrequency(float samplingFrequency, int blockSize, float binNumber)
    {    
	return binNumber*samplingFrequency/blockSize;
    }

    /**
     * Returns the average bin number corresponding to a particular frequency.
     * Note: This function returns a float. Take the Math.round() of the returned value to get an integral bin number. 
     * 
     * @param samplingFrequency The Sampling Frequency of the AudioContext
     * @param blockSize The size of the fft block
     * @param freq  The frequency
     */

    public  float binNumber(float samplingFrequency, int blockSize, float freq)
    {
	return blockSize*freq/samplingFrequency;
    }

    /** The nyquist frequency for this samplingFrequency 
     * 
     * @params samplingFrequency the sample
     */
    public  float nyquist(float samplingFrequency)
    {
	return samplingFrequency/2;
    }

    /*
     * All of the code below this line is taken from Holger Crysandt's MPEG7AudioEnc project.
     * See http://mpeg7audioenc.sourceforge.net/copyright.html for license and copyright.
     */

    /**
     * Gets the real part from the complex spectrum.
     * 
     * @param spectrum
     *            complex spectrum.
     * @param length 
     *       length of data to use.
     * 
     * @return real part of given length of complex spectrum.
     */
    protected  float[] calculateReal(float[] spectrum, int length) {
	float[] real = new float[length];
	real[0] = spectrum[0];
	real[real.length/2] = spectrum[1];
	for (int i=1, j=real.length-1; i<j; ++i, --j)
	    real[j] = real[i] = spectrum[2*i];
	return real;
    }

    /**
     * Gets the imaginary part from the complex spectrum.
     * 
     * @param spectrum
     *            complex spectrum.
     * @param length 
     *       length of data to use.
     * 
     * @return imaginary part of given length of complex spectrum.
     */
    protected  float[] calculateImaginary(float[] spectrum, int length) {
	float[] imag = new float[length];
	for (int i=1, j=imag.length-1; i<j; ++i, --j)
	    imag[i] = -(imag[j] = spectrum[2*i+1]);
	return imag;
    }

    /**
     * Perform FFT on data with given length, regular or inverse.
     * 
     * @param data the data
     * @param n the length
     * @param isign true for regular, false for inverse.
     */
    protected  void fft(float[] data, int n, boolean isign) {
	float c1 = 0.5f; 
	float c2, h1r, h1i, h2r, h2i;
	double wr, wi, wpr, wpi, wtemp;
	double theta = 3.141592653589793f/(n>>1);
	if (isign) {
	    c2 = -.5f;
	    four1(data, n>>1, true);
	} 
	else {
	    c2 = .5f;
	    theta = -theta;
	}
	wtemp = Math.sin(.5f*theta);
	wpr = -2.f*wtemp*wtemp;
	wpi = Math.sin(theta);
	wr = 1.f + wpr;
	wi = wpi;
	int np3 = n + 3;
	for (int i=2,imax = n >> 2, i1, i2, i3, i4; i <= imax; ++i) {
	    /** @TODO this can be optimized */
	    i4 = 1 + (i3 = np3 - (i2 = 1 + (i1 = i + i - 1)));
	    --i4; 
	    --i2; 
	    --i3; 
	    --i1; 
	    h1i =  c1*(data[i2] - data[i4]);
	    h2r = -c2*(data[i2] + data[i4]);
	    h1r =  c1*(data[i1] + data[i3]);
	    h2i =  c2*(data[i1] - data[i3]);
	    data[i1] = (float) ( h1r + wr*h2r - wi*h2i);
	    data[i2] = (float) ( h1i + wr*h2i + wi*h2r);
	    data[i3] = (float) ( h1r - wr*h2r + wi*h2i);
	    data[i4] = (float) (-h1i + wr*h2i + wi*h2r);
	    wr = (wtemp=wr)*wpr - wi*wpi + wr;
	    wi = wi*wpr + wtemp*wpi + wi;
	}
	if (isign) {
	    float tmp = data[0]; 
	    data[0] += data[1];
	    data[1] = tmp - data[1];
	} 
	else {
	    float tmp = data[0];
	    data[0] = c1 * (tmp + data[1]);
	    data[1] = c1 * (tmp - data[1]);
	    four1(data, n>>1, false);
	}
    }

    /**
     * four1 algorithm.
     * 
     * @param data
     *            the data.
     * @param nn
     *            the nn.
     * @param isign
     *            regular or inverse.
     */
    private  void four1(float data[], int nn, boolean isign) {
	int n, mmax, istep;
	double wtemp, wr, wpr, wpi, wi, theta;
	float tempr, tempi;

	n = nn << 1;        
	for (int i = 1, j = 1; i < n; i += 2) {
	    if (j > i) {
		// SWAP(data[j], data[i]);
		float swap = data[j-1];
		data[j-1] = data[i-1];
		data[i-1] = swap;
		// SWAP(data[j+1], data[i+1]);
		swap = data[j];
		data[j] = data[i]; 
		data[i] = swap;
	    }      
	    int m = n >> 1;
	    while (m >= 2 && j > m) {
		j -= m;
		m >>= 1;
	    }
	    j += m;
	}
	mmax = 2;
	while (n > mmax) {
	    istep = mmax << 1;
	    theta = 6.28318530717959f / mmax;
	    if (!isign)
		theta = -theta;
	    wtemp = Math.sin(0.5f * theta);
	    wpr = -2.0f * wtemp * wtemp;
	    wpi = Math.sin(theta);
	    wr = 1.0f;
	    wi = 0.0f;
	    for (int m = 1; m < mmax; m += 2) {
		for (int i = m; i <= n; i += istep) {
		    int j = i + mmax;
		    tempr = (float) (wr * data[j-1] - wi * data[j]);  
		    tempi = (float) (wr * data[j]   + wi * data[j-1]);  
		    data[j-1] = data[i-1] - tempr;
		    data[j]   = data[i] - tempi;
		    data[i-1] += tempr;
		    data[i]   += tempi;
		}
		wr = (wtemp = wr) * wpr - wi * wpi + wr;
		wi = wi * wpr + wtemp * wpi + wi;
	    }
	    mmax = istep;
	}
    }
}


//import ddf.minim.*;
//import ddf.minim.ugens.*;

public class RhythmPlayer  extends Pattern implements BeatClient
{
	//AudioPlayer player;
	BeatKeeper beatKeeper;
	//AudioSample kick;
	boolean active = true;
	float freq;
	int currentLevel;
	public static final int NOISE = 1;
	public static final int SINE = 2;
	public static final int SAW = 3;
	public static final int TRIANGLE = 5;
	public static final int SQUARE = 4;
    int generator;
    int volume = 100;
	//Minim minim;
	//AudioOutput out;

	//Sampler     kick;
	public RhythmPlayer(int[] pattern, float freq )
	{
		 this.Pattern(pattern);
		 this.freq = freq;
	}
	public RhythmPlayer(int[] pattern)
	{
		 this.Pattern(pattern);
		 this.freq = 3000;
	}
	public RhythmPlayer()
	{

	}
	public void setGenerator(int g)
	{
		this.generator = g;
	}
	public void setVolume(int v)
	{
		this.volume = v;
	}
	public void setFrequency(float freq)
	{
		this.freq = freq;
	}

	public Buffer getBuffer()
	{
		if(this.generator == this.SINE)
		{
			return Buffer.SINE;
		}
		if(this.generator == this.SQUARE)
		{
			return Buffer.SQUARE;
		}
		if(this.generator == this.SAW)
		{
			return Buffer.SAW;
		}
		if(this.generator == this.NOISE)
		{
			return Buffer.NOISE;
		}
		if(this.generator == this.TRIANGLE)
		{
			return Buffer.TRIANGLE;
		}
		
		return Buffer.SINE;
	}
	public void beat()
	{
		
		 if(!this.active)
		 {
		 	return;
		 }
	     currentLevel= this.advance();
	   
	     if(true || currentLevel > 0)
	     {
	     	  //println(level + "/" + this.getMax());
	     float percLevel =(float)currentLevel/(float)this.getMax();
	     //println(percLevel);
	     float theVolume = volume * 0.3f / 100;
	     
		 Buffer buf = this.getBuffer();
         WavePlayer wp = new WavePlayer(audioContext, this.freq , buf);
          Gain g = new Gain(audioContext, 1, new Envelope(audioContext,theVolume * percLevel));
          ((Envelope)g.getGainEnvelope()).addSegment(0, 1000, new KillTrigger(g));
          g.addInput(wp);
          audioContext.out.addInput(g);
      	}
		
		
	}

	public void registerBeatKeeper(BeatKeeper bk )
	{
		this.beatKeeper = bk;
	}
	public int getCurrentLevel()
	{
		return this.currentLevel;
	}

	public void setActive(boolean b )
	{
		this.active = b;
		
	}
	public boolean isActive()
	{
		return this.active;
	}
}
class Pattern
{
	int[] structure;
	int max;
	int pointer = 0;

	public void Pattern(int[] structure)
	{
		this.setStructure(structure);
	}

	public int[] getPattern()
	{
		return this.structure;
	}

	public int getPointer()
	{
		return this.pointer;
	}

	public int getNextPointer()
	{
		if(this.pointer == this.structure.length - 1)
		{
			return 0;
		}
		return this.pointer + 1;
	}

	public int getPatternLength()
	{
		return this.structure.length;
	}


	public int getMax()
	{
		return this.max;
	}

	public int advance()
	{
		this.pointer ++;
		if(this.pointer >= this.structure.length)
		{
			this.pointer = 0;
		}

		return this.structure[this.pointer];
	}

	public void printStructure(int[] structure)
	{
		for(int i = 0; i <  structure.length; i++)
		{
			print(structure[i]);

		}
		println("");
	}
	public void setStructure(int[] structure)
	{
		//println("Setting structure to ");
		//this.printStructure(structure);
		this.structure = structure;
		int locmax = 0;
		for(int i = 0; i <  structure.length; i++)
		{
			if(structure[i] > locmax)
			{
				locmax = structure[i];
			}

		}
		this.max = locmax;
	}
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "euRiddm" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
